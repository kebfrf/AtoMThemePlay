# Corcovado theme

This theme is used for reference purposes in our [theming guide](https://www.accesstomemory.org/en/docs/2.3/admin-manual/customization/theming).

## Screenshot

![Screenshot](images/image.big.png)
